<div class="container">
    <p align="right">Dnes je: <?php
    echo date('d.m.Y')."\n";
    ?></p>
    <div class="row">
      <div class="address">
          <p>Vitajte späť</p>
          <div class="location_image">
              <!--Source: https://pixabay.com/en/ -->
              <img src="assets/supervisor.jpg">
          </div>
      </div>
    </div>
</div>
