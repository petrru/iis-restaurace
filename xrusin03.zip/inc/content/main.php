<div class="main_image">
    <!--Source: https://pixabay.com/en/ -->
    <img src="assets/mainimage.jpg">
</div>
