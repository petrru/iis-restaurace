<div class="container">
    <h3>Stránka nenalezena</h3>

    Je nám líto, ale tato stránka neexistuje.
</div>
