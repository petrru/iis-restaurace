<div class="container">
    <h3>Stránka nenalezena</h3>

    Sorry jako, tady nic není.
</div>