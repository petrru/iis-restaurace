<div class="container">
    <h3>Kontakt</h3>

    <div class="row">
        <div class="column_50">
            <div class="address">
                <h4>Kde nás nájdete</h4>
                <p>Dúhová ulica 15<br>612 00 Brno - Královo Pole<br>Česká Republika</p>
                <div class="location_image">
                    <!--Source: https://pixabay.com/en/ -->
                    <img src="assets/location.jpg">
                </div>
            </div>
        </div>
        <div class="column_50">
            <div class="contacts">
                <h4>Kontaktujte nás</h4>
                <p>
                    Tel.: +421908589221<br>Fax: +421905739448<br><br>
                    <a href="mailto:loscompaneros@restaurante.info.cz">Email: loscompaneros@restaurante.info.cz</a>
                </p>
                <div class="location_image">
                    <!--Source: https://pixabay.com/en/ -->
                    <img src="assets/callus.jpg">
                </div>
            </div>
        </div>
    </div>
</div>
