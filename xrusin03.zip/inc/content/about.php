<div class="container">
    <h3>O nás</h3>
    <p>Dos compañeros - reštaurácia zameraná na tradičnú českú a slovenskú kuchyňu.</p>
    <p>Každý deň pe Vás pripravujeme jedlá z čestvých surovín domáceho pôvodu.</p>
    <p>Neváhajte a príďte ochutnať špeciality nášho prvotriedneho šéfkuchára Igora Sánku!</p>
</div>
