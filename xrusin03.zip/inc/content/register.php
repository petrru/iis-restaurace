<!--
<div class="incorrect_data">
    Nesprávne meno alebo heslo.
</div>-->

<div class="login_form">
    <form>
        <h3>Registrace</h3>
        <!-- <form action="/action_page.php"> -->
        Prihlasovacie meno:<br>
        <input type="text" name="username"><br>
        Heslo:<br>
        <input type="text" name="password"><br>
        Jméno:<br>
        <input type="text" name="first_name"><br>

        <div class="button">
            <input type="submit" value="Prihlásiť sa">
        </div>

        <div class="loggedin">
            <p><a href="login">Zpět na přihlášení</a></p>
        </div>
    </form>
</div>
