<?php
$db_conn_str = "mysql:host=localhost;dbname=iis;charset=utf8mb4";
$db_username = "root";
$db_password = "root";
