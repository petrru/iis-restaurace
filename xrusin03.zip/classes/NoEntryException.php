<?php

class NoEntryException extends Exception
{

}