<?php

/**
 * Class NoEntryException
 * Záznam nebyl nalezen (chyba při čtení řádku s neexistujícím ID)
 */
class NoEntryException extends Exception
{

}